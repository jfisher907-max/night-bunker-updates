# Night Bunker installer. Downloads the Electron runtime from GitHub (checked against its
# published SHA-256), adds the game, and creates Start menu and desktop shortcuts.
$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'   # the progress bar makes Invoke-WebRequest very slow
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

$ElectronVersion = '44.5.1'
$ElectronSha256  = '9b382492dcfee91f8f9e92c91f7972550a1b95d2299cac72279dab33a600d7db'
$Here    = Split-Path -Parent $MyInvocation.MyCommand.Path
$Target  = Join-Path $env:LOCALAPPDATA 'Programs\Night Bunker'
$Exe     = Join-Path $Target 'Night Bunker.exe'
$Cache   = Join-Path $env:TEMP "night-bunker-electron-$ElectronVersion.zip"

Write-Host ''
Write-Host '  NIGHT BUNKER  installer' -ForegroundColor Red
Write-Host "  Installing to $Target"
Write-Host ''

foreach ($f in 'app.asar', 'icon.ico') {
  if (-not (Test-Path (Join-Path $Here $f))) { throw "$f is missing. Unzip the whole download into a folder first, then run the installer from there." }
}

$needDownload = $true
if (Test-Path $Cache) { $needDownload = (Get-FileHash $Cache -Algorithm SHA256).Hash -ne $ElectronSha256 }
if ($needDownload) {
  Write-Host '  Downloading the game runtime (about 150 MB, one time only)...'
  $url = "https://github.com/electron/electron/releases/download/v$ElectronVersion/electron-v$ElectronVersion-win32-x64.zip"
  Invoke-WebRequest -Uri $url -OutFile $Cache -UseBasicParsing
  $hash = (Get-FileHash $Cache -Algorithm SHA256).Hash
  if ($hash -ne $ElectronSha256) { Remove-Item $Cache -Force; throw "The download did not match its checksum. Please run the installer again." }
}

Write-Host '  Unpacking...'
# Never close the game out from under a run: wait for the player to quit it (the run is saved either way, and the
# menu offers to continue it after the update). Pressing C closes it now instead.
if (Get-Process -Name 'Night Bunker' -ErrorAction SilentlyContinue) {
  Write-Host ''
  Write-Host '  Night Bunker is running. Finish your run and quit the game; the update carries on by itself.' -ForegroundColor Yellow
  Write-Host '  (Your run is saved as you play, so you can also press C here to close it now and continue the run after.)'
  while (Get-Process -Name 'Night Bunker' -ErrorAction SilentlyContinue) {
    try { if ([Console]::KeyAvailable -and ([Console]::ReadKey($true).Key -eq 'C')) { Get-Process -Name 'Night Bunker' -ErrorAction SilentlyContinue | Stop-Process -Force; Start-Sleep -Seconds 1 } } catch {}
    Start-Sleep -Milliseconds 500
  }
  Write-Host '  Game closed. Updating...'
}
if (Test-Path $Target) { Remove-Item $Target -Recurse -Force }
New-Item -ItemType Directory -Path $Target -Force | Out-Null
Expand-Archive -Path $Cache -DestinationPath $Target -Force
Remove-Item (Join-Path $Target 'resources\default_app.asar') -Force -ErrorAction SilentlyContinue
Copy-Item (Join-Path $Here 'app.asar') (Join-Path $Target 'resources\app.asar') -Force
Copy-Item (Join-Path $Here 'icon.ico') (Join-Path $Target 'icon.ico') -Force
Rename-Item (Join-Path $Target 'electron.exe') 'Night Bunker.exe'

Write-Host '  Creating shortcuts...'
$shell = New-Object -ComObject WScript.Shell
$links = @(
  (Join-Path ([Environment]::GetFolderPath('Programs')) 'Night Bunker.lnk'),
  (Join-Path ([Environment]::GetFolderPath('Desktop')) 'Night Bunker.lnk')
)
foreach ($l in $links) {
  $s = $shell.CreateShortcut($l)
  $s.TargetPath = $Exe; $s.WorkingDirectory = $Target
  $s.IconLocation = (Join-Path $Target 'icon.ico'); $s.Description = 'Night Bunker'
  $s.Save()
}

Write-Host ''
Write-Host '  Done. Starting Night Bunker. Next time use the desktop or Start menu shortcut.' -ForegroundColor Green
Start-Process -FilePath $Exe -WorkingDirectory $Target
Start-Sleep -Seconds 2
