@echo off
title Night Bunker installer
powershell -NoProfile -ExecutionPolicy Bypass -Command "Get-ChildItem -LiteralPath '%~dp0' | Unblock-File; & '%~dp0install.ps1'"
if errorlevel 1 (
  echo.
  echo   Something went wrong. The message above says what.
  pause
)
