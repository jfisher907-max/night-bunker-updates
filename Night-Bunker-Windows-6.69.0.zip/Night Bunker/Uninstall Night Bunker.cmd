@echo off
title Night Bunker uninstaller
powershell -NoProfile -ExecutionPolicy Bypass -Command "Get-Process -Name 'Night Bunker' -ErrorAction SilentlyContinue | Stop-Process -Force; Remove-Item -Recurse -Force \"$env:LOCALAPPDATA\Programs\Night Bunker\" -ErrorAction SilentlyContinue; Remove-Item -Force \"$([Environment]::GetFolderPath('Programs'))\Night Bunker.lnk\",\"$([Environment]::GetFolderPath('Desktop'))\Night Bunker.lnk\" -ErrorAction SilentlyContinue; Write-Host 'Night Bunker removed. Your saves in %APPDATA%\Night Bunker were kept.'"
pause
