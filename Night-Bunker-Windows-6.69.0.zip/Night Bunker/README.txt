NIGHT BUNKER for Windows

1. Unzip this folder anywhere (right-click the zip, Extract All).
2. Double-click "Install Night Bunker.cmd".
   It downloads the game runtime (about 150 MB, from GitHub) the first time,
   then installs the game, adds desktop and Start menu shortcuts, and starts it.
   If Windows shows "Windows protected your PC", click More info, then Run anyway.
3. Play from the "Night Bunker" shortcut from then on.

UPDATES: you never need to reinstall again. When a new version is out, the title
screen shows "Update ready" with an Update now button. Click it; the game closes,
updates itself and reopens in a few seconds, with your saves and run kept.
It finds updates online and also in your Downloads folder (any newer
Night-Bunker-Windows zip there). Display > Check for updates checks right away.

Your save is kept in %APPDATA%\Night Bunker.
To remove the game, run "Uninstall Night Bunker.cmd" (your save is kept).

F11 or Alt+Enter toggles fullscreen. Display options are on the title and pause screens.
